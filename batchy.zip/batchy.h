#ifndef BATCHY_H
#define BATCHY_H

#include <map>
#include <cstring>		//needed for memset

#define RegCount 8
#define RegSize 4		//4*8 = 32 bit
#define StackCount 32	//32*4*8 = 1024 bit

struct cmd_char{
	unsigned char id;
	unsigned char reg;
	unsigned char parameter[RegSize];
};
union cmd{
	unsigned char full[RegSize+2];
	cmd_char splited;
};
union Register{
	bool bits[RegSize*8];
	unsigned char byte[RegSize];
};
struct parameterFunction{
	unsigned char p1;
	unsigned char p2;
	unsigned char p3;
	unsigned char p4;
	
	bool operator < (const parameterFunction &c2) const{
		return p1 < c2.p2 || 
		(p1 == c2.p1 && p2 < c2.p2) ||
		(p2 == c2.p2 && p3 < c2.p3) ||
		(p3 == c2.p3 && p4 < c2.p4);
	}
};

class BATCHY{
	private:
		typedef void (BATCHY::*FnPtr)(unsigned char, unsigned char*);
		typedef std::map<unsigned char, FnPtr> internalMapDef;
		internalMapDef internalMap;
		
		Register batchyReg[RegCount];
		Register batchyStack[StackCount];
		int batchyStackNr = 0;
		
		unsigned char* eepromInternal;
		
		void clear_register(unsigned char reg, unsigned char* nr2);
		void set_register(unsigned char reg, unsigned char* parameter);
		void add_register(unsigned char reg, unsigned char* parameter);
		void sub_register(unsigned char reg, unsigned char* parameter);
		void mul_register(unsigned char reg, unsigned char* parameter);
		void div_register(unsigned char reg, unsigned char* parameter);
		void push_stack(unsigned char reg, unsigned char* parameter);
		void pop_stack(unsigned char reg, unsigned char* parameter);
		void call(unsigned char reg, unsigned char* parameter);
		
	public:
		BATCHY(int eepromInternalSize);
		~BATCHY();
		Register* getRegister(){return batchyReg;}
		void clear_register();
		void runCommandLink(cmd& command);
		void runCommand(cmd command);
		
		typedef void (*FnPtrBATCHY)(BATCHY&, unsigned char);
		typedef std::map<parameterFunction, FnPtrBATCHY> BATCHYMapDef;
		BATCHYMapDef BATCHYMap;
};


namespace BATCHY_FUNCTIONS{
	void tempi(BATCHY &b, unsigned char regReturn){
		//b.
	}
}

//core functions
void BATCHY::clear_register(){
	for(int i = 0; i < RegCount; i++)
		for(int z = 0; z < RegSize; z++)
			batchyReg[i].byte[z] = 0;
}
void BATCHY::clear_register(unsigned char reg, unsigned char* a){
	if(reg < RegCount)
		for(int z = 0; z < RegSize; z++)
			batchyReg[reg].byte[z] = 0;
}
void BATCHY::set_register(unsigned char reg, unsigned char* parameter){
	if(reg < RegCount){
		for(int z = 0; z < RegSize; z++)
			batchyReg[reg].byte[z] = parameter[z];
	}
}
void BATCHY::add_register(unsigned char reg, unsigned char* parameter){	//reg = parameter[0] + parameter[1]
	char buff = 0;
	for(int z = RegSize-1; z >= 0; z--){
		batchyReg[reg].byte[z] = batchyReg[parameter[0]].byte[z] + batchyReg[parameter[1]].byte[z] + buff;
		buff = batchyReg[reg].byte[z] < (batchyReg[parameter[0]].byte[z] + batchyReg[parameter[1]].byte[z] + buff);
	}
}
void BATCHY::sub_register(unsigned char reg, unsigned char* parameter){	//reg = parameter[0] - parameter[1]
	char buff = 0;
	for(int z = RegSize-1; z >= 0; z--){
		batchyReg[reg].byte[z] = batchyReg[parameter[0]].byte[z] - batchyReg[parameter[1]].byte[z] - buff;
		buff = batchyReg[reg].byte[z] != (batchyReg[parameter[0]].byte[z] - batchyReg[parameter[1]].byte[z] - buff);
	}
}
void BATCHY::mul_register(unsigned char reg, unsigned char* parameter){
	
}
void BATCHY::div_register(unsigned char reg, unsigned char* parameter){
	
}
void BATCHY::push_stack(unsigned char reg, unsigned char* parameter){
	if((batchyStackNr+1) < StackCount){
		for(int z = 0; z < RegSize; z++)
			batchyStack[batchyStackNr].byte[z] = parameter[z];
		batchyStackNr += 1;
	}
}
void BATCHY::pop_stack(unsigned char reg, unsigned char* parameter){
	if(batchyStackNr > 0){
		batchyStackNr -= 1;
		/*for(int z = 0; z < RegSize; z++)
			batchyStack[batchyStackNr].byte[z] = 0;*/
	}
}
void BATCHY::call(unsigned char reg, unsigned char* parameter){
	BATCHYMapDef::iterator x = BATCHYMap.find({parameter[0], parameter[1], parameter[2], parameter[3]});
	
    if (x != BATCHYMap.end()) {
        (*(x->second))(*this, reg);
    }
}

//public functions
BATCHY::BATCHY(int eepromInternalSize = 1000){
	clear_register();		//clear_register all
	
	internalMap[1] = &BATCHY::clear_register;
	internalMap[2] = &BATCHY::set_register;
	internalMap[3] = &BATCHY::add_register;
	internalMap[4] = &BATCHY::sub_register;
	internalMap[5] = &BATCHY::mul_register;
	internalMap[6] = &BATCHY::div_register;
	internalMap[7] = &BATCHY::push_stack;
	internalMap[8] = &BATCHY::pop_stack;
	internalMap[9] = &BATCHY::call;
	
	//BATCHY MAP INIT
	BATCHYMap[{0,0,0,1}] = BATCHY_FUNCTIONS::tempi;
	
	eepromInternal = new unsigned char[eepromInternalSize];
	std::memset(eepromInternal, 0, sizeof eepromInternal);
}
BATCHY::~BATCHY(){
	delete[] eepromInternal;
}

void BATCHY::runCommandLink(cmd& command){
	internalMapDef::iterator x = internalMap.find(command.splited.id);
	
    if (x != internalMap.end()) {
        (*this.*(x->second))(command.splited.reg, (unsigned char*)command.splited.parameter);
    }
}
void BATCHY::runCommand(cmd command){
	runCommandLink(command);
}


#endif
